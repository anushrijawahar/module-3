package com.cg.wrapper;


//Implicit Casting of a Class Type

class Parent
{
	public void disp()
	{
		System.out.println("Parent disp called");
	}
}
public class ChildN extends Parent
{
	public static void main(String args[])
	{
		Parent p = new ChildN();
		p.disp();
	}
}
