package com.cg.wrapper;

public class Explicit_casting_Class {
	public void disp()
	{
		System.out.println("Parent disp called");
	}
}
public class Child extends Parent
{
	public void disp()
	{
		System.out.println("Child disp called");
	}
	public static void main(String args[])
	{
		Parent p = new Child();
		p.disp();
		//Child c = p;  /*In order to fix the code, then we need to cast it to Child class
		
		Child c = (Child) p;
		c.disp();
	}


}
