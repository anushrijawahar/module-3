package com.cg.wrapper;

public class parseIntDemo {
	public static void main(String args[]) 
    { 
        int decimalExample = Integer.parseInt("20"); 
        int signedPositiveExample = Integer.parseInt("+20"); 
        int signedNegativeExample = Integer.parseInt("-20"); 
        int radixExample = Integer.parseInt("20",16); /*Converts 20 hexa to decimal 32 */
        int stringExample = Integer.parseInt("abcd",29); /* Number system with base 29 can have digits 0-9 
        followed by characters a,b,c... upto s */

  
        // Uncomment the following code to check 
        // NumberFormatException 
  
         // String invalidArguments = ""; 
         // int emptyString = Integer.parseInt(invalidArguments); 
         // int outOfRangeOfInteger = Integer.parseInt("Rutuja",29); 
         // int domainOfNumberSystem = Integer.parseInt("Rutuja",28); 
  
        System.out.println(decimalExample); 
        System.out.println(signedPositiveExample); 
        System.out.println(signedNegativeExample); 
        System.out.println(radixExample); 
        System.out.println(stringExample); 
    } 


}
