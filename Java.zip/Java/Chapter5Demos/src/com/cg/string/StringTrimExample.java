package com.cg.string;

public class StringTrimExample{  
public static void main(String args[]){  
String s1="  hello      string   ";  
System.out.println(s1+"Rutuja");//without trim()  
System.out.println(s1.trim()+"Rutuja");//with trim()  
}}  
