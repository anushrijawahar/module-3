package com.cg.string;

public class ReplaceAllExample3{  
public static void main(String args[]){  
String s1="My   name is    Rutuja      K";  
String replaceString=s1.replaceAll("\\s","");  
System.out.println(replaceString);  
}}  
