package com.cg.SingleLevel;

class Animal{  
void eat()
{
	System.out.println("eating...");}  
}  
class Dog extends Animal{  
void bark()
{
	System.out.println("barking...");}  
}  

