package com.cg.overriding;

class child extends parent {
	 public void work() {
	  System.out.println("Child has a job");
	  System.out.println(" He is doing it well");
	 }
	 public static void main(String argu[]) {
	  child c1 = new child();
	 // parent c2 = new parent();
	  c1.work();
	  //c2.work();
	 }
	}

