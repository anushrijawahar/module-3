package com.cg.overriding;

class parent {
	 public void work() {
	  System.out.println("Parent is under retirement from work.");
	 }
	}
	