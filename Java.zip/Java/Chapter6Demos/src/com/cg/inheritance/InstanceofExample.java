package com.cg.inheritance;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class InstanceofExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object testObject = LocalTime.now();
	    if (testObject instanceof LocalDate)
	      System.out.println("Object was an instance of the class java.time.LocalDate");
	    else if (testObject instanceof LocalDateTime)
	      System.out.println("Object was an instance of the class java.time.LocalDateTime");
	    else 
	      System.out.println("Object was an instance of the " + testObject.getClass());

	  
	}

}
