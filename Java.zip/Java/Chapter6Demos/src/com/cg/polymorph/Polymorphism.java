package com.cg.polymorph;

class Polymorphism {
	 public static void main(String args[]) {
	  Mltply m = new Mltply();
	  m.mul(6, 10);
	  m.mul(10, 6, 5);
	 }
	}
